//1 initialize search term as an empty string
let displayTerm = "";

//2  main function
function getData() {
    console.log("getData() called");
}

//3 set up event handler for button click to call function
document.querySelector("#search").onclick = getData;

